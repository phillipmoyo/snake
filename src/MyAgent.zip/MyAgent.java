import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Random;


public class MyAgent extends za.ac.wits.snake.MyAgent {

    public static void main(String args[]) throws IOException {
        MyAgent agent = new MyAgent();
        MyAgent.start(agent, args);
    }

    @Override
    public void run() {
        try (BufferedReader br = new BufferedReader(new InputStreamReader(System.in))) {
            String initString = br.readLine();//initialization which is likely 4 50 50 1
            String[] temp = initString.split(" ");//{[4,50,50,1]} string format
            int nSnakes = Integer.parseInt(temp[0]); //number of snakes ==> 4

            while (true) {
            	/*keep on reading the game state
            	 * apple ==> x,y
       
            	 * obstacle 1 ==> x,y...x,y
            	 * obstacle 2 ==> x,y...x,y
            	 * obstacle 3 ==> x,y...x,y
            	 
            	 * my snake number e.g 3 
            
            	 * snake 0 ==> x,y...x,y
            	 * snake 1 ==> x,y...x,y
            	 * snake 2 ==> x,y...x,y
            	 * snake 3 ==> x,y...x,y
            	 
            	 * NOTE: in each snake e.g snake 0
            	 * alive/dead length kills x,y...x,y
            	 * */
            	
                String line = br.readLine();
                if (line.contains("Game Over")) {
                    break;
                }

                String apple1 = line;
                //do stuff with apples
                ////////////////////////////////////////////////////////////////////////////////////
                Point Apple = new Point();
                Apple.SplitArrayInt(apple1, " ");
                
                ////////////////////////////////////////////////////////////////////////////////////
                
                         
                // read in obstacles and do something with them!
                int nObstacles = 3;
                /////////////////////////////////////////////
                Point hitWall = new Point();
                ///////////////////////////////////////////////
                for (int obstacle = 0; obstacle < nObstacles; obstacle++) {
                    String obs = br.readLine();
                    /// do something with obs
                    ////////////////////////////////////////////////////////////////////////////////
                    String[] wall = obs.split(" ");
                    for(int i = 0; i < wall.length; i++)
                    {
                        hitWall.SplitArrayInt(wall[i], ",");
                    }
                    ////////////////////////////////////////////////////////////////////////////////
                    
                }
         
                int mySnakeNum = Integer.parseInt(br.readLine());//my snake index
                ////////////////////////////////////////////////////////
                String[] mySnake = null;
                ArrayList<String> otherSnakes = new ArrayList<>();
                //////////////////////////////////////////////////////
                for (int i = 0; i < nSnakes; i++) {
                    String snakeLine = br.readLine();//my snake line
                    if (i == mySnakeNum) {
                        //hey! That's me :)
                    	////////////////////////////////////////////////////
                    	mySnake = snakeLine.split(" ");
                    	///////////////////////////////////////////////////
                    }
                    //do stuff with other snakes
                    ////////////////////////////////////////////
                    otherSnakes.add(snakeLine);
                }
                
                /**Summary of what i currently have
                 * 
                 *1)stored the coordinates of apple in Apple
                 *2)stored my snake number in mySnakeNum
                 *3)stored my snake state in []mySnake >>>N/A
                 *4)Stored other snake's status in (ArrayList)[]otherSnake >>>>N/A
                 * 
                 * **/
                
                //finished reading, calculate move:
                
                /////////////////////////////processing happens here///////////////////////////////////////
                Point point = new Point();
                point.SplitArrayInt(mySnake[3], ",");
                
                int move = move(point,Apple,CurrentMovementDirection(mySnake[3],mySnake[4]));
      
//                int move = new Random().nextInt(4);
                System.out.println(move);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        
    }
    
    int move(Point head, Point apple, String direction)
    {
    	if(head.X == apple.X)
    	{
    		if(direction.equals("upwards"))
    		{
    			if(apple.Y > head.Y)//note we swaped(1) with (2)
    			{
    				return 3;//decisions need to be made/wall
    			}
    			else
    			{
    				return 5;
    			}
    		}
    		else if(direction.equals("downwards"))//(2)
    		{
    			if(head.Y > apple.Y)
    			{
    				return 3;//decisions need to be made/wall
    			}
    			else
    			{
    				return 5;
    			}
    		}
    		else if(direction.equals("left") || direction.equals("right"))
    		{
    			if(head.Y > apple.Y)
    			{
    				return 0;
    			}
    			else
    			{
    				return 1;
    			}
    		}
    	}
    	else if(head.Y == apple.Y )
    	{
    		if(direction.equals("upwards") || direction.equals("downwards"))
    		{
    			if(head.X > apple.X)
    			{
    				return 2;
    			}
    			else
    			{
    				return 3;
    			}
    		}
    		else if(direction.equals("left"))
    		{
    			if(head.X > apple.X)
    			{
    				return 5;
    			}
    			else
    			{
    				return 0;//need working/wall
    			}
    		}
    		else if(direction.equals("right"))
    		{
    			if(apple.X > head.X)
    			{
    				return 5;
    			}
    			else
    			{
    				return 0;//need working/wall
    			}
    		}
    		else
    		{
    			return 5;//not that important
    		}
    	}
    	else if(head.X != apple.X && head.Y != apple.Y)
    	{
    		if(head.X > apple.X && head.Y > apple.Y)
    		{
    			if(direction.equals("right"))
    			{
    				return 0;
    			}
    			else if(direction.equals("downwards"))
    			{
    				return 2;
    			}
    			else
    			{
    				return 5;
    			}
    		}
    		else if(apple.X > head.X && apple.Y > head.Y)
    		{
    			if(direction.equals("left"))
    			{
    				return 1;
    			}
    			else if(direction.equals("upwards"))
    			{
    				return 3;
    			}
    			else
    			{
    				return 5;
    			}
    		}
    		else if(head.X > apple.X && apple.Y > head.Y)
    		{
    			if(direction.equals("right"))
    			{
    				return 1;
    			}
    			else if(direction.equals("upwards"))
    			{
    				return 2;
    			}
    			else
    			{
    				return 5;
    			}
    		}
    		else if(apple.X > head.X && head.Y > apple.Y)
    		{
    			if(direction.equals("left"))
    			{
    				return 0;
    			}
    			else if(direction.equals("downwards"))
    			{
    				return 3;
    			}
    			else
    			{
    				return 5;
    			}
    		}
    	}
    	return 5;
    }
    
    
    String CurrentMovementDirection(String XYhead ,String XYnext)
    {
    	
    	Point head = new Point();
    	Point next = new Point();
    	head.SplitArrayInt(XYhead, ",");
    	next.SplitArrayInt(XYnext, ",");
    	
    	
    	if(head.X == next.X )
    	{
    		if(head.Y < next.Y)
    		{
    			return "upwards";
    			//we moving upwards
    		}
    		else if(head.Y > next.Y)
    		{
    			return "downwards";
    			//we moving downwards
    		}
    		
    	}
    	if(head.Y == next.Y)
    	{
    		if(head.X < next.X)
    		{
    			return "left";
    			//we moving left
    		}
    		else if(head.X > next.X)
    		{
    			return "right";
    			//we moving right
    		}
    	}
		return null;
    }
    
}